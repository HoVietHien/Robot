# 202_Robotics_BTL

This is my Robotics Assignment under PhD. Nguyen Hoang Giap instruction

Demo video: https://youtu.be/iK2cu8upVA0
