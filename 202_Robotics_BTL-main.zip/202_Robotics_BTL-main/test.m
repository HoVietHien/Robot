
if isnan(str2double('nigga'))
    disp('hihi')
end